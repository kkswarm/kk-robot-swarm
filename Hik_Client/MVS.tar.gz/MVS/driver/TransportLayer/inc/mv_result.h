
#ifndef __RESULT_H__
#define __RESULT_H__

#ifdef __cplusplus
extern "C"
{
#endif // __cplusplus

// typedef enum
// {
//     MV_RESULT_PACKET_IGNORED = -2,
//     MV_RESULT_END_OF_BLOCK = -1,
//     MV_RESULT_OK = 0,
//     MV_RESULT_FAIL,
//     MV_RESULT_OUT_OF_MEMORY,
//     MV_RESULT_NOT_ENOUGH_SPACE,
//     MV_RESULT_OUT_OF_RESOURCES,
//     MV_RESULT_TIMEOUT,
//     MV_RESULT_NOT_IMPLEMENTED,
//     MV_RESULT_INVALID_CONFIG,
//     MV_RESULT_INVALID_ARGUMENT,
//     MV_RESULT_BAD_SIZE,
//     MV_RESULT_NO_REQUEST_FOUND,
//     MV_RESULT_NOT_FOUND,
//     MV_RESULT_NOT_CONNECTED,
//     MV_RESULT_WRONG_DESTINATION,
//     MV_RESULT_PENDING,
//     MV_RESULT_ONLY_ONE_CALL_ALLOWED_AT_THE_TIME,
//     /*Insert all error codes above here */
//     MV_RESULT_LAST
// } MV_RESULT;

#ifdef __cplusplus
}
#endif // __cplusplus

#endif // __RESULT_H__
