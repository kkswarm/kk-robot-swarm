/*
@ @licstart  The following is the entire license notice for the
JavaScript code in this file.

Copyright (C) 1997-2017 by Dimitri van Heesch

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

@licend  The above is the entire license notice
for the JavaScript code in this file
*/
var menudata={children:[
{text:"声明",url:"_xE5_xA3_xB0_xE6_x98_x8E.html"},
{text:"简介",url:"index.html"},
{text:"相关页面",url:"pages.html"},
{text:"模块",url:"modules.html"},
{text:"结构体",url:"annotated.html",children:[
{text:"结构体",url:"annotated.html"},
{text:"成员变量",url:"functions.html",children:[
{text:"全部",url:"functions.html",children:[
{text:"b",url:"functions.html#index_b"},
{text:"c",url:"functions_c.html#index_c"},
{text:"d",url:"functions_d.html#index_d"},
{text:"e",url:"functions_e.html#index_e"},
{text:"f",url:"functions_f.html#index_f"},
{text:"h",url:"functions_h.html#index_h"},
{text:"i",url:"functions_i.html#index_i"},
{text:"n",url:"functions_n.html#index_n"},
{text:"p",url:"functions_p.html#index_p"},
{text:"s",url:"functions_s.html#index_s"},
{text:"u",url:"functions_u.html#index_u"}]},
{text:"变量",url:"functions_vars.html",children:[
{text:"b",url:"functions_vars.html#index_b"},
{text:"c",url:"functions_vars_c.html#index_c"},
{text:"d",url:"functions_vars_d.html#index_d"},
{text:"e",url:"functions_vars_e.html#index_e"},
{text:"f",url:"functions_vars_f.html#index_f"},
{text:"h",url:"functions_vars_h.html#index_h"},
{text:"i",url:"functions_vars_i.html#index_i"},
{text:"n",url:"functions_vars_n.html#index_n"},
{text:"p",url:"functions_vars_p.html#index_p"},
{text:"s",url:"functions_vars_s.html#index_s"},
{text:"u",url:"functions_vars_u.html#index_u"}]}]}]},
{text:"头文件",url:"files.html",children:[
{text:"文件列表",url:"files.html"},
{text:"全局定义",url:"globals.html",children:[
{text:"全部",url:"globals.html",children:[
{text:"_",url:"globals.html#index__5F"},
{text:"a",url:"globals_a.html#index_a"},
{text:"b",url:"globals_b.html#index_b"},
{text:"f",url:"globals_f.html#index_f"},
{text:"i",url:"globals_i.html#index_i"},
{text:"m",url:"globals_m.html#index_m"},
{text:"t",url:"globals_t.html#index_t"},
{text:"v",url:"globals_v.html#index_v"}]},
{text:"函数",url:"globals_func.html",children:[
{text:"m",url:"globals_func.html#index_m"}]},
{text:"类型定义",url:"globals_type.html"},
{text:"枚举",url:"globals_enum.html"},
{text:"枚举值",url:"globals_eval.html",children:[
{text:"a",url:"globals_eval.html#index_a"},
{text:"i",url:"globals_eval.html#index_i"},
{text:"m",url:"globals_eval.html#index_m"},
{text:"v",url:"globals_eval.html#index_v"}]},
{text:"宏定义",url:"globals_defs.html",children:[
{text:"_",url:"globals_defs.html#index__5F"},
{text:"f",url:"globals_defs.html#index_f"},
{text:"i",url:"globals_defs.html#index_i"},
{text:"m",url:"globals_defs.html#index_m"},
{text:"t",url:"globals_defs.html#index_t"}]}]}]},
{text:"示例",url:"examples.html"}]}
