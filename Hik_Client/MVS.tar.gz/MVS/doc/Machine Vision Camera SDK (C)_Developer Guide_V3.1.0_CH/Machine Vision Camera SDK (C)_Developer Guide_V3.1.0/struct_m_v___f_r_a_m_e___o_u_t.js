var struct_m_v___f_r_a_m_e___o_u_t =
[
    [ "pBufAddr", "struct_m_v___f_r_a_m_e___o_u_t.html#ad09dec12abbdf5f6b77c47105e7eaaa9", null ],
    [ "stFrameInfo", "struct_m_v___f_r_a_m_e___o_u_t.html#a2587481f4ebfe4e2dcc78f073978772a", null ],
    [ "nRes", "struct_m_v___f_r_a_m_e___o_u_t.html#adaa4b71a6fc2947325e8ed4c3f6d1ca2", null ]
];