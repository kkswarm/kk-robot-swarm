var group___x_m_l_xE8_xA7_xA3_xE6_x9E_x90 =
[
    [ "MV_XML_GetGenICamXML", "group___x_m_l_xE8_xA7_xA3_xE6_x9E_x90.html#gaa7de63c22089aa7d0cd54ac245b758af", null ],
    [ "MV_XML_GetRootNode", "group___x_m_l_xE8_xA7_xA3_xE6_x9E_x90.html#gad75d46bb2a3f07117f3ec2a6b1bed7cd", null ],
    [ "MV_XML_GetChildren", "group___x_m_l_xE8_xA7_xA3_xE6_x9E_x90.html#ga48acaa97d99baf9d792dc72ffa49a073", null ],
    [ "MV_XML_GetNodeFeature", "group___x_m_l_xE8_xA7_xA3_xE6_x9E_x90.html#gaa3fafe6d248336598adcad441d98bfd7", null ],
    [ "MV_XML_UpdateNodeFeature", "group___x_m_l_xE8_xA7_xA3_xE6_x9E_x90.html#ga33faabff04587aa6d6b021dabf77c05e", null ],
    [ "MV_XML_RegisterUpdateCallBack", "group___x_m_l_xE8_xA7_xA3_xE6_x9E_x90.html#ga804a321859ef19f951b9290a293ff28a", null ]
];