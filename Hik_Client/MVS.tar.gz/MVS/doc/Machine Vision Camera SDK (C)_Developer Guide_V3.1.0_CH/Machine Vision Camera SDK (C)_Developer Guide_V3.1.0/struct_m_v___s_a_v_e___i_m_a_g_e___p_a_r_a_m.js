var struct_m_v___s_a_v_e___i_m_a_g_e___p_a_r_a_m =
[
    [ "pData", "struct_m_v___s_a_v_e___i_m_a_g_e___p_a_r_a_m.html#aaf2599b3eef445bee5a6bd50569435f7", null ],
    [ "nDataLen", "struct_m_v___s_a_v_e___i_m_a_g_e___p_a_r_a_m.html#a437032205be38dd5298407ae8b4a2b87", null ],
    [ "enPixelType", "struct_m_v___s_a_v_e___i_m_a_g_e___p_a_r_a_m.html#adea006ae805402cd96d9f8548235da30", null ],
    [ "nWidth", "struct_m_v___s_a_v_e___i_m_a_g_e___p_a_r_a_m.html#a523c75b72da2a3bb32b97032f86c4703", null ],
    [ "nHeight", "struct_m_v___s_a_v_e___i_m_a_g_e___p_a_r_a_m.html#a33071a62b54a3c9a671a0fcbe4804f1a", null ],
    [ "pImageBuffer", "struct_m_v___s_a_v_e___i_m_a_g_e___p_a_r_a_m.html#ad31a20e4c310f622fa7618dfe185d546", null ],
    [ "nImageLen", "struct_m_v___s_a_v_e___i_m_a_g_e___p_a_r_a_m.html#a3d447a537b6803b07341a5ed1a9372d4", null ],
    [ "nBufferSize", "struct_m_v___s_a_v_e___i_m_a_g_e___p_a_r_a_m.html#a2de66d98e4ec27d07ab609f6e188c905", null ],
    [ "enImageType", "struct_m_v___s_a_v_e___i_m_a_g_e___p_a_r_a_m.html#a9e97c82636424e576989acc7f5b65e48", null ]
];