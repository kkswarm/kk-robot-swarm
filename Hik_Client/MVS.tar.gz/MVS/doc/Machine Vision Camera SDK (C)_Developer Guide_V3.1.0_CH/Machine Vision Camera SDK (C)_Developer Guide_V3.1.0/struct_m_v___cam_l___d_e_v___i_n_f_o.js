var struct_m_v___cam_l___d_e_v___i_n_f_o =
[
    [ "chPortID", "struct_m_v___cam_l___d_e_v___i_n_f_o.html#a3282c77712c5c7e0e080a1b60dbe0452", null ],
    [ "chModelName", "struct_m_v___cam_l___d_e_v___i_n_f_o.html#a1fd78924df9302fb6421706ddb10c6db", null ],
    [ "chFamilyName", "struct_m_v___cam_l___d_e_v___i_n_f_o.html#a05182e86a909b28a9f65e7fca5f55ee3", null ],
    [ "chDeviceVersion", "struct_m_v___cam_l___d_e_v___i_n_f_o.html#ad0de70a48d62da180d462e56471c9873", null ],
    [ "chManufacturerName", "struct_m_v___cam_l___d_e_v___i_n_f_o.html#a64ddff82613d44350e1ef5ab15fa6b1b", null ],
    [ "chSerialNumber", "struct_m_v___cam_l___d_e_v___i_n_f_o.html#a11ec0d40110082cc595ad659bfceeeb7", null ],
    [ "nReserved", "struct_m_v___cam_l___d_e_v___i_n_f_o.html#a77708606d9b7c74876791f8a5e281538", null ]
];