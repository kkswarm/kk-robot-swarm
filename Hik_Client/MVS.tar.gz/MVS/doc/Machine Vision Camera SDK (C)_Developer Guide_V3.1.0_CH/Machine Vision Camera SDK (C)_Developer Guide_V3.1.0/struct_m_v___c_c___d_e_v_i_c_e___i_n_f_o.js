var struct_m_v___c_c___d_e_v_i_c_e___i_n_f_o =
[
    [ "nMajorVer", "struct_m_v___c_c___d_e_v_i_c_e___i_n_f_o.html#a75a04ff55dbe05caaca5da58d012a3e5", null ],
    [ "nMinorVer", "struct_m_v___c_c___d_e_v_i_c_e___i_n_f_o.html#a7f47cbac2330b54a0da963eb7c5606bd", null ],
    [ "nMacAddrHigh", "struct_m_v___c_c___d_e_v_i_c_e___i_n_f_o.html#a1e008a836c0e409ddf82f52fcb02033c", null ],
    [ "nMacAddrLow", "struct_m_v___c_c___d_e_v_i_c_e___i_n_f_o.html#a92ad9c1911d71ba6fbb2e433183b6a6b", null ],
    [ "nTLayerType", "struct_m_v___c_c___d_e_v_i_c_e___i_n_f_o.html#a3b26b1c9681dba57af81bdb7ed795575", null ],
    [ "nReserved", "struct_m_v___c_c___d_e_v_i_c_e___i_n_f_o.html#a36997a85b4eaded7b74d90ca41312fee", null ],
    [ "stGigEInfo", "struct_m_v___c_c___d_e_v_i_c_e___i_n_f_o.html#aab5fcc9de5a7fa798f170a8453818cc5", null ],
    [ "stUsb3VInfo", "struct_m_v___c_c___d_e_v_i_c_e___i_n_f_o.html#a3bea622a6d4adb297c2a8c99f28c54eb", null ],
    [ "stCamLInfo", "struct_m_v___c_c___d_e_v_i_c_e___i_n_f_o.html#aab0864b98d3663236462d9fe254f6a94", null ],
    [ "SpecialInfo", "struct_m_v___c_c___d_e_v_i_c_e___i_n_f_o.html#ad8047fbdb096b8801b869f00db151c69", null ]
];