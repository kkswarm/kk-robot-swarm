var struct_m_v___c_h_u_n_k___d_a_t_a___c_o_n_t_e_n_t =
[
    [ "pChunkData", "struct_m_v___c_h_u_n_k___d_a_t_a___c_o_n_t_e_n_t.html#a647605d766e4a513ad9f00203c3428a1", null ],
    [ "nChunkID", "struct_m_v___c_h_u_n_k___d_a_t_a___c_o_n_t_e_n_t.html#a45254518e0f8137849ce75d381d671ef", null ],
    [ "nChunkLen", "struct_m_v___c_h_u_n_k___d_a_t_a___c_o_n_t_e_n_t.html#a5c2386c95f4c4b59c072f204d236af6e", null ],
    [ "nReserved", "struct_m_v___c_h_u_n_k___d_a_t_a___c_o_n_t_e_n_t.html#a6ee3001d9cdc554c411058ef6690e6a1", null ]
];