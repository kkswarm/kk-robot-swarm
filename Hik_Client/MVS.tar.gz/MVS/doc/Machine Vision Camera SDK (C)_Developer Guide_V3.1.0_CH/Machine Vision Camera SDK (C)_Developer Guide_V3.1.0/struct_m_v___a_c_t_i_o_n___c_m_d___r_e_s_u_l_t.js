var struct_m_v___a_c_t_i_o_n___c_m_d___r_e_s_u_l_t =
[
    [ "strDeviceAddress", "struct_m_v___a_c_t_i_o_n___c_m_d___r_e_s_u_l_t.html#a2d7515919892aa786c9f7be32be3655b", null ],
    [ "nStatus", "struct_m_v___a_c_t_i_o_n___c_m_d___r_e_s_u_l_t.html#a49bdd539d5adc5220d3acdaeca5fc571", null ],
    [ "nReserved", "struct_m_v___a_c_t_i_o_n___c_m_d___r_e_s_u_l_t.html#a36997a85b4eaded7b74d90ca41312fee", null ]
];