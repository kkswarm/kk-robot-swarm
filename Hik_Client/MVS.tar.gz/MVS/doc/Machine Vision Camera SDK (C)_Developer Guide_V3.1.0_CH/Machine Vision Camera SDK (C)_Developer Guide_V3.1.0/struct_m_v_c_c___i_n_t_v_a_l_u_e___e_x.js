var struct_m_v_c_c___i_n_t_v_a_l_u_e___e_x =
[
    [ "nCurValue", "struct_m_v_c_c___i_n_t_v_a_l_u_e___e_x.html#a75858d445833ad0bbe60edfa610f7f7b", null ],
    [ "nMax", "struct_m_v_c_c___i_n_t_v_a_l_u_e___e_x.html#ac3b89b1f2afc6c4d9714783ddda44669", null ],
    [ "nMin", "struct_m_v_c_c___i_n_t_v_a_l_u_e___e_x.html#ad96b7da4286c033b0a8ae7c916d180e1", null ],
    [ "nInc", "struct_m_v_c_c___i_n_t_v_a_l_u_e___e_x.html#a0d3310c18a2a2bac3eb43a1613aed5de", null ],
    [ "nReserved", "struct_m_v_c_c___i_n_t_v_a_l_u_e___e_x.html#a0cb5815a0bf085826c780576fa8135a8", null ]
];