var struct_m_v_c_c___i_n_t_v_a_l_u_e =
[
    [ "nCurValue", "struct_m_v_c_c___i_n_t_v_a_l_u_e.html#a83b19189b7bee89a25ea1f31e96e46e5", null ],
    [ "nMax", "struct_m_v_c_c___i_n_t_v_a_l_u_e.html#abb1923b8422bf5f73704009a86caf91b", null ],
    [ "nMin", "struct_m_v_c_c___i_n_t_v_a_l_u_e.html#ad7d171213abe001b8e7263c4bcd5221b", null ],
    [ "nInc", "struct_m_v_c_c___i_n_t_v_a_l_u_e.html#af8c816fc06c9241c33820a8d06c306fa", null ],
    [ "nReserved", "struct_m_v_c_c___i_n_t_v_a_l_u_e.html#a36997a85b4eaded7b74d90ca41312fee", null ]
];