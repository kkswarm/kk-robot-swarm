var struct_m_v___c_c___f_i_l_e___a_c_c_e_s_s =
[
    [ "pUserFileName", "struct_m_v___c_c___f_i_l_e___a_c_c_e_s_s.html#a98c927bd20826c7b054cbac8295ee46b", null ],
    [ "pDevFileName", "struct_m_v___c_c___f_i_l_e___a_c_c_e_s_s.html#abddd31e5c91892bbbd8e406ed6ef5e1b", null ],
    [ "nReserved", "struct_m_v___c_c___f_i_l_e___a_c_c_e_s_s.html#a81173acf7817c987cbbf0d4ca8e20b73", null ]
];