var group___xE9_x80_x9A_xE7_x94_xA8_xE6_x8E_xA5_xE5_x8F_xA3 =
[
    [ "MV_CC_IsDeviceConnected", "group___xE9_x80_x9A_xE7_x94_xA8_xE6_x8E_xA5_xE5_x8F_xA3.html#ga25ec535d08180f1c987c20c75b2224a2", null ],
    [ "MV_CC_SetImageNodeNum", "group___xE9_x80_x9A_xE7_x94_xA8_xE6_x8E_xA5_xE5_x8F_xA3.html#gae0c743b164f7093bb7eb74bd271efded", null ],
    [ "MV_CC_GetImageInfo", "group___xE9_x80_x9A_xE7_x94_xA8_xE6_x8E_xA5_xE5_x8F_xA3.html#gaef27561bebcbbadb7086c410f5b34d57", null ],
    [ "MV_CC_GetAllMatchInfo", "group___xE9_x80_x9A_xE7_x94_xA8_xE6_x8E_xA5_xE5_x8F_xA3.html#gaa0b5fc03d13b3d0dc37d06a6e96ed646", null ],
    [ "MV_CC_InvalidateNodes", "group___xE9_x80_x9A_xE7_x94_xA8_xE6_x8E_xA5_xE5_x8F_xA3.html#ga4ef6fa3b866fe11dfacf6514d8a289d0", null ],
    [ "MV_CC_RegisterExceptionCallBack", "group___xE9_x80_x9A_xE7_x94_xA8_xE6_x8E_xA5_xE5_x8F_xA3.html#gabee2d01f28f6a7fe35c5f09a9d04a002", null ],
    [ "MV_CC_RegisterAllEventCallBack", "group___xE9_x80_x9A_xE7_x94_xA8_xE6_x8E_xA5_xE5_x8F_xA3.html#gae35bcf2ae0cfc78b3ae19a1bd4cdb355", null ],
    [ "MV_CC_RegisterEventCallBackEx", "group___xE9_x80_x9A_xE7_x94_xA8_xE6_x8E_xA5_xE5_x8F_xA3.html#ga5e1784d7e9557617a1a50b353d0d74dc", null ],
    [ "MV_CC_FeatureSave", "group___xE9_x80_x9A_xE7_x94_xA8_xE6_x8E_xA5_xE5_x8F_xA3.html#ga67a46bb04e884d20e664cdfa51831ef9", null ],
    [ "MV_CC_FeatureLoad", "group___xE9_x80_x9A_xE7_x94_xA8_xE6_x8E_xA5_xE5_x8F_xA3.html#ga8ec884bb8dc9680eb158856084545047", null ],
    [ "MV_CC_FileAccessRead", "group___xE9_x80_x9A_xE7_x94_xA8_xE6_x8E_xA5_xE5_x8F_xA3.html#ga50cac3acd95fee2899e7492ffac47db4", null ],
    [ "MV_CC_FileAccessWrite", "group___xE9_x80_x9A_xE7_x94_xA8_xE6_x8E_xA5_xE5_x8F_xA3.html#ga67b69d346a26d82c79091f7bee9e10c9", null ],
    [ "MV_CC_GetFileAccessProgress", "group___xE9_x80_x9A_xE7_x94_xA8_xE6_x8E_xA5_xE5_x8F_xA3.html#ga297d345d4d86e4e31d6be8c364359a88", null ]
];