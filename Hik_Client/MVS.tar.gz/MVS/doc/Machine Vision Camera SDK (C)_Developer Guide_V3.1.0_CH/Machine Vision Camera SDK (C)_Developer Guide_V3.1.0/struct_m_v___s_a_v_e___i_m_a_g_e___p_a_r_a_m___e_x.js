var struct_m_v___s_a_v_e___i_m_a_g_e___p_a_r_a_m___e_x =
[
    [ "pData", "struct_m_v___s_a_v_e___i_m_a_g_e___p_a_r_a_m___e_x.html#aaf2599b3eef445bee5a6bd50569435f7", null ],
    [ "nDataLen", "struct_m_v___s_a_v_e___i_m_a_g_e___p_a_r_a_m___e_x.html#a437032205be38dd5298407ae8b4a2b87", null ],
    [ "enPixelType", "struct_m_v___s_a_v_e___i_m_a_g_e___p_a_r_a_m___e_x.html#adea006ae805402cd96d9f8548235da30", null ],
    [ "nWidth", "struct_m_v___s_a_v_e___i_m_a_g_e___p_a_r_a_m___e_x.html#a523c75b72da2a3bb32b97032f86c4703", null ],
    [ "nHeight", "struct_m_v___s_a_v_e___i_m_a_g_e___p_a_r_a_m___e_x.html#a33071a62b54a3c9a671a0fcbe4804f1a", null ],
    [ "pImageBuffer", "struct_m_v___s_a_v_e___i_m_a_g_e___p_a_r_a_m___e_x.html#ad31a20e4c310f622fa7618dfe185d546", null ],
    [ "nImageLen", "struct_m_v___s_a_v_e___i_m_a_g_e___p_a_r_a_m___e_x.html#a3d447a537b6803b07341a5ed1a9372d4", null ],
    [ "nBufferSize", "struct_m_v___s_a_v_e___i_m_a_g_e___p_a_r_a_m___e_x.html#a2de66d98e4ec27d07ab609f6e188c905", null ],
    [ "enImageType", "struct_m_v___s_a_v_e___i_m_a_g_e___p_a_r_a_m___e_x.html#a9e97c82636424e576989acc7f5b65e48", null ],
    [ "nJpgQuality", "struct_m_v___s_a_v_e___i_m_a_g_e___p_a_r_a_m___e_x.html#a170032d0a182885306c74447a51212b5", null ],
    [ "iMethodValue", "struct_m_v___s_a_v_e___i_m_a_g_e___p_a_r_a_m___e_x.html#ac4f94bc4e57829c1201aae23291a218d", null ],
    [ "nReserved", "struct_m_v___s_a_v_e___i_m_a_g_e___p_a_r_a_m___e_x.html#ab872787b3b33c5deca4467b7cc9dbb09", null ]
];