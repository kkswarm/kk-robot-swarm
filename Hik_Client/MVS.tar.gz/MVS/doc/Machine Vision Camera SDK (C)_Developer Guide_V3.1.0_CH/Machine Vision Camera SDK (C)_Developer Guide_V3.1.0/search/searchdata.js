var indexSectionsWithContent =
{
  0: "_abcdefghimnpstuvxäåçèé",
  1: "m",
  2: "cm",
  3: "m",
  4: "bcdefhinpsu",
  5: "b",
  6: "m",
  7: "aimv",
  8: "_fimt",
  9: "gsxäåçèé",
  10: "å"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "defines",
  9: "groups",
  10: "pages"
};

var indexSectionLabels =
{
  0: "全部",
  1: "结构体",
  2: "文件",
  3: "函数",
  4: "变量",
  5: "类型定义",
  6: "枚举",
  7: "枚举值",
  8: "宏定义",
  9: "组",
  10: "页"
};

