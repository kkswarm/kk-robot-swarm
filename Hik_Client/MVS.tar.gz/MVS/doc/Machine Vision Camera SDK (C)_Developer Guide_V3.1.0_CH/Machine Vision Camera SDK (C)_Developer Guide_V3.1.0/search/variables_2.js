var searchData=
[
  ['dfincrement',['dfIncrement',['../struct_m_v___x_m_l___f_e_a_t_u_r_e___float.html#a2e8abfba782782e5ff616ecf466ba959',1,'MV_XML_FEATURE_Float']]],
  ['dfmaxvalue',['dfMaxValue',['../struct_m_v___x_m_l___f_e_a_t_u_r_e___float.html#a23ba1d9e7b2a41741fc80b63a0d6d578',1,'MV_XML_FEATURE_Float']]],
  ['dfminvalue',['dfMinValue',['../struct_m_v___x_m_l___f_e_a_t_u_r_e___float.html#ad541c99f3c044ae07b51f8c662530320',1,'MV_XML_FEATURE_Float']]],
  ['dfvalue',['dfValue',['../struct_m_v___x_m_l___f_e_a_t_u_r_e___float.html#afeed39884b81acfc52526734fbab9069',1,'MV_XML_FEATURE_Float']]]
];
