var struct_m_v___x_m_l___c_a_m_e_r_a___f_e_a_t_u_r_e =
[
    [ "enType", "struct_m_v___x_m_l___c_a_m_e_r_a___f_e_a_t_u_r_e.html#a290315a8d24c3886c30aaf8c6d03fed9", null ],
    [ "stIntegerFeature", "struct_m_v___x_m_l___c_a_m_e_r_a___f_e_a_t_u_r_e.html#ad060b812742cf524d461a2ccbda18063", null ],
    [ "stFloatFeature", "struct_m_v___x_m_l___c_a_m_e_r_a___f_e_a_t_u_r_e.html#a8a4b0d65197c116540d4b2a14a91a800", null ],
    [ "stEnumerationFeature", "struct_m_v___x_m_l___c_a_m_e_r_a___f_e_a_t_u_r_e.html#a2f29ac5906d299c7dd4b537f2c215619", null ],
    [ "stStringFeature", "struct_m_v___x_m_l___c_a_m_e_r_a___f_e_a_t_u_r_e.html#a2292c855fef1acbb6a6ac3624918590a", null ],
    [ "SpecialFeature", "struct_m_v___x_m_l___c_a_m_e_r_a___f_e_a_t_u_r_e.html#a1aadee1891008da8ad790084e022ea3a", null ]
];