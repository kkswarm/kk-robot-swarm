var struct_m_v___c_c___i_n_p_u_t___f_r_a_m_e___i_n_f_o =
[
    [ "pData", "struct_m_v___c_c___i_n_p_u_t___f_r_a_m_e___i_n_f_o.html#aaf2599b3eef445bee5a6bd50569435f7", null ],
    [ "nDataLen", "struct_m_v___c_c___i_n_p_u_t___f_r_a_m_e___i_n_f_o.html#a437032205be38dd5298407ae8b4a2b87", null ],
    [ "nRes", "struct_m_v___c_c___i_n_p_u_t___f_r_a_m_e___i_n_f_o.html#aa59fef561cbae078ddfc2fb675ea0c47", null ]
];