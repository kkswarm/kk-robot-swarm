var struct_m_v_c_c___s_t_r_i_n_g_v_a_l_u_e =
[
    [ "chCurValue", "struct_m_v_c_c___s_t_r_i_n_g_v_a_l_u_e.html#af0fd08750070e7f2dbba7e89cf4718e4", null ],
    [ "nMaxLength", "struct_m_v_c_c___s_t_r_i_n_g_v_a_l_u_e.html#aecc6c80caf715fd36005ca77303b22ef", null ],
    [ "nReserved", "struct_m_v_c_c___s_t_r_i_n_g_v_a_l_u_e.html#a81cb0717f9db166f066323bfdf9f8dde", null ]
];