var struct_m_v___c_c___d_e_v_i_c_e___i_n_f_o___l_i_s_t =
[
    [ "nDeviceNum", "struct_m_v___c_c___d_e_v_i_c_e___i_n_f_o___l_i_s_t.html#a757ade91f37b0c95b768035d0ec07fdc", null ],
    [ "pDeviceInfo", "struct_m_v___c_c___d_e_v_i_c_e___i_n_f_o___l_i_s_t.html#ac8a3f91cd4d9e7f09ff4abaac031dffc", null ]
];