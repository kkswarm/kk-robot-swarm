var struct_m_v___m_a_t_c_h___i_n_f_o___n_e_t___d_e_t_e_c_t =
[
    [ "nReviceDataSize", "struct_m_v___m_a_t_c_h___i_n_f_o___n_e_t___d_e_t_e_c_t.html#ab23114d93b7c0a387bd352144993d826", null ],
    [ "nLostPacketCount", "struct_m_v___m_a_t_c_h___i_n_f_o___n_e_t___d_e_t_e_c_t.html#acbd3a0bf7d08b1ec6707bcea8ac36a37", null ],
    [ "nLostFrameCount", "struct_m_v___m_a_t_c_h___i_n_f_o___n_e_t___d_e_t_e_c_t.html#a291f3a2fe238831a3e2f627e72678030", null ],
    [ "nNetRecvFrameCount", "struct_m_v___m_a_t_c_h___i_n_f_o___n_e_t___d_e_t_e_c_t.html#a90f4e88cb476d40340d180a67e352c49", null ],
    [ "nRequestResendPacketCount", "struct_m_v___m_a_t_c_h___i_n_f_o___n_e_t___d_e_t_e_c_t.html#a6e0ca8fbfc13258886a557ae22fd4d5a", null ],
    [ "nResendPacketCount", "struct_m_v___m_a_t_c_h___i_n_f_o___n_e_t___d_e_t_e_c_t.html#af5a46bdf52e0bc7d2e18dec7d6e7c65e", null ]
];